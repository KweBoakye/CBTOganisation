package com.fyp.kweku.cbtoganisation.models

data class taskCategory (
    val taskCategory: String,
    val Task: Task
)